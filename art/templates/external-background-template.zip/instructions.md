# External AI background workflow — Custom setting

1. Give your art AI prompt.md and layout.png. It creates ONE complete background, including terrain and all scenery. No sprite sheet or separate ground image is needed.
2. In Theme Studio choose **Import AI background**. The map's logical size and simple zones are preserved, even if the image has a higher resolution.
3. Choose an area in **Adjust an area**. Drag it, resize it, or edit X/Y/width/height. For a hiding area, set the ground line where the tall object meets the floor. Delete unused areas. Keep only a few obstacles and hiding areas.
4. Use **Check paths** and **Walk around it**. Inspect the two hiding areas from both sides. If the background adds clutter or narrow passages, ask the art AI for a revision using the same prompt and guide.
5. Choose a fresh id and name, download the theme file and install it with your AI's background:

npm run theme -- "theme.json" --picture "background.png"

Restart locally or build and deploy, then choose the map for a new game. Use story-context.md when authoring matching missions. Saved games keep their map; saved campaigns keep their original text and answers.

The app prepares the brief and guides and previews the returned artwork. You use your chosen external AI to create the art. Visual review is required: the path check cannot judge artistic alignment.
