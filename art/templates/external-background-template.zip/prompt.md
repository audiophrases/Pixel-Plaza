Create ONE complete square background for Pixel Plaza, a multiplayer social RPG. Return a finished PNG or WebP, preferably 1024 × 1024. All scenery belongs in this single image.

SETTING: Custom setting
SCENE: Describe the entire ground surface and atmosphere. Keep all playable ground clear and continuous.
SEASON / CAMPAIGN / STYLE BRIEF: A welcoming, colorful world with generous space for a class to gather.
SUGGESTED FEATURES: Simple solid feature A; Simple solid feature B; Simple solid feature C; Tall feature A; Tall feature B. These describe this setting, not permanent fixtures.

Use the attached layout.png as a simple gameplay guide. The camera is slightly elevated and orthographic, with a consistent RPG art style. The guide coordinates are 0–1024 on both axes. A standing avatar is about 48 art pixels tall.

PLAYABLE BOUNDARIES — REQUIRED:
The image shows the entire playable map. Make it read as a complete, enclosed place. Every street, road, path, trail and bridge must stay entirely inside the playable area. Routes must loop, turn back inward or end at a clearly visible destination inside the map, such as a building entrance or gathering place.

Close all four sides — top, right, bottom and left — with a continuous, clearly impassable boundary suited to the setting, such as walls, dense hedges, snowbanks, cliffs, shoreline or closed deck railings. Align boundary scenery with the blocked outer edges in layout.png; keep the interior routes and named places accessible. Flat snow, sand, grass or paving alone must not suggest that players can keep walking beyond the map.

No route may touch or cross the playable boundary or any image edge. Do not crop a road at the edge or hide its continuation behind foreground scenery. No open gates, wall gaps, tunnels, stairs or bridges that imply an exit, another screen or more explorable map. Avoid a crossroad whose arms run off the left, right or bottom edge.

Before returning the image, inspect all four edges and every route ending. Each edge must show a closed boundary; each route must visibly turn inward or reach an interior destination without suggesting onward travel.

RED = solid footprints. Place solid scenery over these footprints; keep its base close to the guide. BLUE = the only intentional hiding areas: put a broad, simple foreground silhouette here, with its base near the marked ground line. Players can walk behind this part. Keep silhouettes easy to outline with one oval or a few straight edges. GREEN / unmarked interior = generous, connected walking and gathering space. Flat texture and painted decoration are fine.

Current solid footprints [x,y,width,height]:
{"rectangles":[[0,0,1024,32],[0,32,32,960],[992,32,32,960],[0,992,1024,32],[80,64,240,256],[392,64,240,256],[704,64,240,256]],"otherShapes":[{"shape":"ellipse","rect":[204,750,40,28]},{"shape":"ellipse","rect":[780,750,40,28]}]}
Hiding silhouettes and ground lines:
[{"shape":"ellipse","rect":[144,588,160,166],"sortY":778},{"shape":"ellipse","rect":[720,588,160,166],"sortY":778}]

Keep the start and all five named places accessible. Use only a handful of solid features and at most two intentional hiding features in the starter layout. Avoid tiny posts, dense trees, complex fences, narrow bridges, small gaps, extra solid props or hidden barriers. Keep impassable water/cliffs at blocked edges. Any grass, sand, snow, deck planks, buildings or other scenery can change with the brief; no fountain, park, pond or bridge is required.

Do not paint the guide colors, grid, coordinates, labels, text or characters into the image. Return the complete background only. A human will align the small number of collision and hiding areas in Studio after import; do not add complicated silhouettes that require extensive tracing.