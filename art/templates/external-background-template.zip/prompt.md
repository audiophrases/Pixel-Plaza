Create ONE complete square background for Pixel Plaza, a multiplayer social RPG. Return a finished PNG or WebP, preferably 1024 × 1024. All scenery belongs in this single image.

MANDATORY COMPOSITION: ENCLOSED MAP, ZERO EXTERNAL ENTRANCES OR EXITS.
Show the entire playable place in one image, with its complete perimeter visible. Players appear at the interior start marker; they do not enter from a road outside the picture. These composition rules take priority over the setting, style brief and reference image.

PATH PLAN: Use continuous open ground, or one compact CLOSED LOOP in the interior with short branches ending at visible building doors or other interior destinations. Leave a visible strip of ordinary terrain between the paths and the perimeter. The bottom of the loop turns left/right and closes on itself: it has NO downward stem, approach road or entrance path. Do not add a path from the loop toward the bottom center, even if it stops just before the image edge. Every street, road, trail, footprint track and bridge must remain inside this enclosed composition.

PERIMETER PLAN: Close all four sides — top, right, bottom and left — with one continuous, clearly impassable boundary suited to the setting, such as walls, dense hedges, snowbanks, cliffs, shoreline or closed deck railings. Align it with the blocked outer edges in layout.png; keep the interior routes and named places accessible. At the BOTTOM CENTER, continue the SAME boundary that runs along the bottom-left and bottom-right. Join it without a gap, notch, gate, archway or break. Keep this closure visible rather than obscuring a possible opening behind trees, foreground scenery or fog. Snow, sand, grass or paving alone is not a boundary.

ZERO EXIT CUES: No road cropped by an image edge; no opening in the perimeter; no tunnels, stairs, bridges or tracks suggesting another screen or more explorable map. A village entrance at the bottom is forbidden. If reference.png contains any such feature, replace it with the closed perimeter: reference.png supplies style and scale only, never permission to copy an exit.

FINAL CHECK: Trace the perimeter all the way around, especially across the bottom center. It must form an unbroken enclosure. Trace every path: it must close into the interior loop or end at a visible interior destination. If there is a downward branch, apparent entrance or route to an edge, remove it and restore the continuous boundary before returning the image.

SETTING: Custom setting
SCENE: Describe the entire ground surface and atmosphere. Keep all playable ground clear and continuous.
SEASON / CAMPAIGN / STYLE BRIEF: A welcoming, colorful world with generous space for a class to gather.
SUGGESTED FEATURES: Simple solid feature A; Simple solid feature B; Simple solid feature C; Tall feature A; Tall feature B. These describe this setting, not permanent fixtures.

Use the attached layout.png as a simple gameplay guide. The camera is slightly elevated and orthographic, with a consistent RPG art style. The guide coordinates are 0–1024 on both axes. A standing avatar is about 48 art pixels tall. layout.png is authoritative for geometry. reference.png is for style and avatar scale only; do not copy paths, exits or additional props from it.

RED = solid footprints. Place solid scenery over these footprints; keep its base close to the guide. BLUE = the only intentional hiding areas: put a broad, simple foreground silhouette here, with its base near the marked ground line. Players can walk behind this part. Keep silhouettes easy to outline with one oval or a few straight edges. GREEN / unmarked interior = generous, connected walking and gathering space. Flat texture and painted decoration are fine. Dashed green rectangles mark story areas only: do not trace their outlines as roads, walls or fences. The start marker is an interior spawn, not an entrance or a request for an approach path.

Current solid footprints [x,y,width,height]:
{"rectangles":[[0,0,1024,32],[0,32,32,960],[992,32,32,960],[0,992,1024,32],[80,64,240,256],[392,64,240,256],[704,64,240,256]],"otherShapes":[{"shape":"ellipse","rect":[204,750,40,28]},{"shape":"ellipse","rect":[780,750,40,28]}]}
Hiding silhouettes and ground lines:
[{"shape":"ellipse","rect":[144,588,160,166],"sortY":778},{"shape":"ellipse","rect":[720,588,160,166],"sortY":778}]

Keep the start and all five named places accessible. Use only a handful of solid features and at most two intentional hiding features in the starter layout. Avoid tiny posts, dense trees, complex fences, narrow bridges, small gaps, extra solid props or hidden barriers. Keep impassable water/cliffs at blocked edges. Any grass, sand, snow, deck planks, buildings or other scenery can change with the brief; no fountain, park, pond or bridge is required.

Do not paint the guide colors, grid, coordinates, labels, text or characters into the image. Return the complete background only. A human will align the small number of collision and hiding areas in Studio after import; do not add complicated silhouettes that require extensive tracing.