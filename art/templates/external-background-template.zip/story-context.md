# Story setting: Custom setting

Use these discovery IDs with their visible names:
- hotel: Place A
- cafe: Place B
- shop: Place C
- square: Meeting area
- park: Second meeting area

Scene: Describe the entire ground surface and atmosphere. Keep all playable ground clear and continuous.
Suggested features: Simple solid feature A; Simple solid feature B; Simple solid feature C; Tall feature A; Tall feature B.

Create a matching new campaign. Existing saved stories retain their wording and answers.