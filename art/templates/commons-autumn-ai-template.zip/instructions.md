# Pixel Plaza art brief — Autumn Commons

Creative direction: A welcoming autumn village with amber leaves and warm windows.

Create a square PNG or WebP with TRUE TRANSPARENCY, in a precise 2 × 2 grid of equal cells. 1024 × 1024 or 2048 × 2048 both work. This is an art sheet, not a finished map.

At 1024 pixels:
- Top left [0,0,512,512]: hotel facade.
- Top right [512,0,512,512]: café facade.
- Bottom left [0,512,512,512]: shop facade.
- Bottom right [512,512,512,512]: one tree.

Front-facing, slightly elevated orthographic view. Match the reference's camera and avatar scale. Use one consistent pixel-art style. Keep each object entirely in its own cell with 16 pixels of transparent padding. Buildings have a wide foundation and central entrance, ending at cell y=500; fill most of the cell. Tree: broad rounded crown, short trunk centered at cell x=256, trunk base at y=500. The app fits pieces into fixed slots and uses the tree's transparency for walking behind it.

Rich detail belongs on facades, roofs and crowns. No terrain, surrounding ground, paths, characters, fences, bridges, posts, scene backgrounds, grid lines, labels, or checkerboard baked into the image. Preserve the slot order. Seasonal decorations stay attached to the objects. Do not add objects between the slots.

Return just the transparent art sheet. Do not draw the layout guide or its labels.

## Preview and install

1. Open /studio?theme=commons-autumn. Choose **New treatment**, then **Open AI art sheet**.
2. Check the preview and **Walk around it**. Walk behind both trees from north and south.
3. Name the treatment, choose an unused id and download the theme file.
4. Run: npm run theme -- "path/to/downloaded-theme.json" --sheet "path/to/ai-art.png"
5. Restart the server (or build and deploy). Select the new map when creating a game. Existing games keep their maps.

The ground and all ten collision pieces remain fixed. Do not import the art sheet as the background picture. A new 2K sheet requires no geometry edits.

## Files

- layout.png: gameplay geometry, not finished artwork.
- reference.png: current appearance with avatar scale.
- art-sheet-guide.png: slot positions (Commons only).
- commons-autumn.json: geometry and art placement.

Layout: commons-v1. World: 2048 × 2048. Art coordinates: 1024 × 1024.
