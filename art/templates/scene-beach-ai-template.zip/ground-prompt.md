Setting: Summer beach. Creative direction: A welcoming, colorful world with generous space for a class to gather.

Create one square 1024 × 1024 opaque ground/background image for a social RPG. Warm pale sand across the playable area, subtle footprints and turquoise water confined to the outer border. No grass, plaza paving or pond.

Use a consistent, slightly elevated orthographic game camera and pixel-art style. The whole interior (between the outer 32-pixel borders on the 1024-coordinate guide) must be clear, continuous walking ground. Texture and flat painted decoration are welcome. Do not add buildings, trees, rocks, furniture, ponds, pools, fences, stairs, characters or other solid/tall objects: the app places those separately. Water, cliffs and other impassable terrain may appear only inside the blocked outer border. No text, grid, labels or guide colors.

Every visible surface can change: snow, sand, deck planks, colors and atmosphere. There are no mandatory grass, paving, fountain, bridge or pond fixtures. Return only the finished ground image.