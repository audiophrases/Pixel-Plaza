# Story setting: Summer beach

Create a new adventure appropriate to this scenery. Use these exact zone IDs in discovery definitions, and their visible names in story text:
- hotel: Bungalow
- cafe: Beach café
- shop: Surf shack
- square: Open beach
- park: Palm cove

Scenery: Beach bungalow; Beach café hut; Surf rental hut; Palm tree; Palm tree; Rounded beach rock.
Ground: Warm pale sand across the playable area, subtle footprints and turquoise water confined to the outer border. No grass, plaza paving or pond.

Do not assume a hotel, park, fountain or bridge unless it is named above. Existing saved stories keep their original wording and answers; this context is for creating a matching new campaign in Mission Studio.