# Full scenery workflow — Summer beach

1. Give your art AI ground-prompt.md and layout.png. Generate the square ground image.
2. Give it scenery-prompt.md, art-sheet-guide.png and the generated ground as a style reference. Generate the transparent six-cell sheet.
3. In Studio, open the ground with **Open AI ground** and the sheet with **Open AI art sheet**. All ten collision pieces and both foreground anchors remain in place.
4. Walk around, behind the two tall objects and around the low oval obstacle. Check that art and solid footprints agree. Name the scenery, choose a fresh id, and download its theme file.
5. Install both files:

npm run theme -- "theme.json" --picture "ground.png" --sheet "scenery.png"

Restart the server or build and deploy, then select this map for a new game.

The ground, all six objects and visible place names can change. Geometry is reusable; no scenery object is mandatory. Use story-context.md to create matching missions. Existing campaigns are not automatically rewritten.

The guide is geometry, not a required artistic style. Generated images need a visual check; if a sprite does not fit its cell or base, ask the AI for a correction rather than tracing a new mask.
