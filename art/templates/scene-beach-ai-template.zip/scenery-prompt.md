Setting: Summer beach. Creative direction: A welcoming, colorful world with generous space for a class to gather.

Create one TRUE TRANSPARENT PNG or WebP art sheet, preferably 1536 × 1024, arranged in THREE columns and TWO rows of equal cells. Exactly six isolated sprites in this order:
1. Top row, left: Beach bungalow
2. Top row, middle: Beach café hut
3. Top row, right: Surf rental hut
4. Bottom row, left: Palm tree
5. Bottom row, middle: Palm tree
6. Bottom row, right: Rounded beach rock

Each object stays entirely inside its own cell with transparent padding. Match the ground image's camera, lighting and style. The first three sprites are large solid objects; they fill most of their cells, with a broad base at the bottom. They need not be buildings. Slots 4 and 5 are tall foreground objects: base centered horizontally, near the bottom of the cell; keep a short, sturdy base and a broad silhouette. They need not be trees. Slot 6 is a low solid rounded feature. Draw it approximately circular within its cell; the app fits it into a low oval. It can be a rock, snowbank, pool, planter or any appropriate obstacle.

No surrounding ground, background scenery, characters, captions, grid lines, cell borders, watermark or painted checkerboard. Preserve real alpha around each sprite. The app positions these pieces and uses their transparency to hide players; do not render a complete map in this image. Return only the six-cell art sheet.